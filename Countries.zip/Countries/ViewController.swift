//
//  ViewController.swift
//  Countries
//
//  Created by Test2 on 07/06/2022.
//

import UIKit

class ViewController: UIViewController {

    struct Country {
        let name: String
        let population: Int
        let imageName: String
        var continent: Continent
    }
    
    enum Continent: String {
        case america = "America"
        case europe = "Europe"
        case asia = "Asia"
        case oceania = "Oceania"
        case africa = "Africa"
        case antarctica = "Antarctica"
    }

        
    let countryList = [
        Country(name: "Argentina", population: 45_000_000, imageName: "ar", continent: .america),
        Country(name: "Austria", population: 9_000_000, imageName: "at", continent: .europe),
        Country(name: "Denmark", population: 6_000_000, imageName: "dk", continent: .europe),
        Country(name: "Finland", population: 5_500_000, imageName: "fi", continent: .europe),
        Country(name: "Scotland", population: 5_500_000, imageName: "gb-sct", continent: .europe),
        Country(name: "South Korea", population: 52_000_000, imageName: "kr", continent: .asia),
        Country(name: "Netherlands", population: 17_000_000, imageName: "nl", continent: .europe),
        Country(name: "Peru", population: 33_000_000, imageName: "pe", continent: .america),
        Country(name: "Rwanda", population: 13_000_000, imageName: "rw", continent: .africa),
        Country(name: "Senegal", population: 16_000_000, imageName: "sn", continent: .africa),
        Country(name: "Uruguay", population: 3_500_000, imageName: "uy", continent: .america),
        Country(name: "South Africa", population: 59_000_000, imageName: "za", continent: .africa),
    ]
    var countriesToShow: [Country] = []
    
    @IBOutlet weak var countryCollectionView: UICollectionView!
    @IBOutlet weak var continentSegmentedControl: UISegmentedControl!
    @IBAction func indexChanged(_ sender: UISegmentedControl) {

        switch sender.selectedSegmentIndex {
        case 0:
            countriesToShow = countryList
        case 1:
            countriesToShow = countryList.filter{ $0.continent == .europe}
        case 2:
            countriesToShow = countryList.filter{ $0.continent == .america}

        default:
            countriesToShow = countryList
        }
        countryCollectionView.reloadData()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        countriesToShow = countryList
        countryCollectionView.dataSource = self
    }
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return countriesToShow.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let countryCell = collectionView.dequeueReusableCell(withReuseIdentifier: "countryCellId", for: indexPath) as! CountryCollectionViewCell
        
        let country = countriesToShow[indexPath.row]

        countryCell.countryNameLabel.text = country.name
        countryCell.flagImageView.image = UIImage(named: country.imageName)
        countryCell.continentLabel.text = country.continent.rawValue
        
        let population = NumberFormatter()
        population.numberStyle = .decimal
        guard let formattedPopulation = population.string(from: NSNumber(value: country.population)) else {
            return countryCell
        }
        countryCell.countryPopulationLabel.text = String(formattedPopulation)
        return countryCell
    }
}

class CountryCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var flagImageView: UIImageView!
    @IBOutlet weak var countryNameLabel: UILabel!
    
    @IBOutlet weak var countryPopulationLabel: UILabel!
    @IBOutlet weak var continentLabel: UILabel!
    

    
    
}
